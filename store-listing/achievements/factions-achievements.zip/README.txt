Factions — Play Games Services achievements import
=====================================================

This ZIP contains the complete achievement set for Factions, ready
to import into Play Console → Play Games Services → Achievements
→ Bulk import.

Achievements: 13
Total points: 560 / 1000 Play Games cap

Files (all at ZIP root — Play Console rejects subfolders):
  AchievementsMetadata.csv        one row per achievement
  AchievementsLocalizations.csv   en-US copy for each achievement
  AchievementsIconsMappings.csv   which icon belongs to which key
  *.png                           13 × 512×512 PNG icons

To upload:
  1. Unzip locally.
  2. Open each CSV in a spreadsheet editor + verify the column
     headers match whatever Play Console's current importer
     expects. Google has tweaked these names between releases;
     if the upload rejects the file, adjust here and retry.
  3. Re-zip everything (CSVs + the icons/ folder) and upload.
  4. After import, Play Console assigns each achievement a final
     ID (format: CgkI...). Copy those back into
     src/data/Achievements.ts — replace the empty-string
     placeholders for the 11 FIRST_WIN_<FACTION> entries + the
     DISCOVER_CREEPS incremental id.

Source of truth: scripts/build-achievements-zip.mjs. Regenerate
this ZIP any time the in-code ACHIEVEMENTS list changes.
